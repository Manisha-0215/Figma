# Figma Assignment — Influencer Platform Billing UI

A pixel-perfect React implementation of the billing/checkout page for an influencer collaboration platform.

## 🚀 Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) to view it in the browser.

## 🏗️ Project Structure

```
figma-assignment/
├── public/
│   └── favicon.ico
├── src/
│   ├── components/
│   │   ├── common/           # Reusable atoms
│   │   │   ├── BackLink.jsx
│   │   │   ├── Badge.jsx
│   │   │   ├── Button.jsx
│   │   │   ├── FormInput.jsx
│   │   │   ├── FormSelect.jsx
│   │   │   └── SearchBar.jsx
│   │   ├── layout/           # Shell components
│   │   │   ├── Header.jsx
│   │   │   └── LayoutWrapper.jsx
│   │   └── dashboard/        # Page-specific organisms
│   │       ├── BillingForm.jsx
│   │       ├── CouponSelector.jsx
│   │       └── OrderSummary.jsx
│   ├── pages/
│   │   └── CheckoutPage.jsx
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── tailwind.config.js
├── vite.config.js
└── package.json
```

## 🎨 Design Tokens

| Token        | Value     |
|--------------|-----------|
| Primary Blue | `#2563EB` |
| Orange       | `#F59E0B` |
| Background   | `#F3F4F6` |
| Card BG      | `#FFFFFF` |
| Border       | `#E5E7EB` |
| Text Primary | `#111827` |
| Text Muted   | `#6B7280` |

## 🧩 Components

### Common (Atoms)
- **Button** — Multi-variant button (primary, secondary, orange, outline, ghost)
- **FormInput** — Labeled input with optional tag support
- **FormSelect** — Custom-styled dropdown select
- **SearchBar** — Search input with icon
- **BackLink** — Animated back navigation link
- **Badge** — Status/label badge

### Layout
- **Header** — Sticky top navbar with search, upgrade, create campaign, avatar
- **LayoutWrapper** — Page shell with header + main content area

### Dashboard (Organisms)
- **BillingForm** — Full billing info form with state-managed inputs
- **OrderSummary** — Plan info, wallet, coupons, totals, and payment CTA
- **CouponSelector** — Selectable coupon radio list

## 🛠️ Tech Stack

- **React 18** with functional components and hooks
- **Tailwind CSS 3** for utility-first styling
- **Lucide React** for icons
- **Vite** for fast development
