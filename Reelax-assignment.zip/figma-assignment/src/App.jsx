import React from 'react'
import LayoutWrapper from './components/layout/LayoutWrapper'
import CheckoutPage from './pages/CheckoutPage'

const App = () => {
  return (
    <LayoutWrapper>
      <CheckoutPage />
    </LayoutWrapper>
  )
}

export default App
