import React from 'react'
import { Menu, Zap, Plus } from 'lucide-react'
import SearchBar from '../common/SearchBar'
import Button from '../common/Button'

const Header = () => {
  return (
    <header className="w-full bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between sticky top-0 z-50">
      {/* Left: Search */}
      <SearchBar placeholder="Find influencers to collaborate with" />

      {/* Right: Actions */}
      <div className="flex items-center gap-3">
        {/* Upgrade Button */}
        <Button
          variant="orange"
          size="sm"
          icon={<Zap size={13} fill="white" />}
          className="rounded-md text-xs font-semibold px-3.5 py-2"
        >
          Upgrade
        </Button>

        {/* Create Campaign Button */}
        <Button
          variant="primary"
          size="sm"
          icon={<Plus size={14} />}
          className="rounded-md text-xs font-semibold px-3.5 py-2"
        >
          Create Campaign
        </Button>

        {/* Avatar */}
        <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden flex items-center justify-center cursor-pointer hover:ring-2 hover:ring-primary/30 transition-all">
          <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            <circle cx="16" cy="16" r="16" fill="#E5E7EB" />
            <circle cx="16" cy="13" r="5" fill="#9CA3AF" />
            <ellipse cx="16" cy="27" rx="9" ry="6" fill="#9CA3AF" />
          </svg>
        </div>

        {/* Hamburger Menu */}
        <button className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 transition-colors cursor-pointer">
          <Menu size={18} />
        </button>
      </div>
    </header>
  )
}

export default Header
