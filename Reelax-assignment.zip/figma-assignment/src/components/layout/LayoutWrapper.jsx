import React from 'react'
import Header from './Header'

const LayoutWrapper = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      <main className="flex-1 px-6 py-6 max-w-[1100px] mx-auto w-full">
        {children}
      </main>
    </div>
  )
}

export default LayoutWrapper
