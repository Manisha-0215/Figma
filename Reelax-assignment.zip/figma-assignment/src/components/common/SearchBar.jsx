import React from 'react'
import { Search } from 'lucide-react'

const SearchBar = ({ placeholder = 'Search...', value, onChange }) => {
  return (
    <div className="relative flex items-center">
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="w-[320px] pl-4 pr-10 py-2 text-sm text-gray-700 bg-white border border-gray-200 
                   rounded-lg placeholder-gray-400 outline-none focus:border-primary 
                   focus:ring-2 focus:ring-primary/10 transition-all duration-150"
      />
      <button className="absolute right-3 text-gray-400 hover:text-gray-600 transition-colors">
        <Search size={16} />
      </button>
    </div>
  )
}

export default SearchBar
