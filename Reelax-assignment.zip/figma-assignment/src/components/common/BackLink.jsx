import React from 'react'
import { ArrowLeft } from 'lucide-react'

const BackLink = ({ label = 'Back', onClick }) => {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 
                 transition-colors cursor-pointer mb-5 group"
    >
      <ArrowLeft
        size={15}
        className="group-hover:-translate-x-0.5 transition-transform duration-150"
      />
      {label}
    </button>
  )
}

export default BackLink
