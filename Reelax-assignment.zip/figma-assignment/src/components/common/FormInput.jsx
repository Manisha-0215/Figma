import React from 'react'

const FormInput = ({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  optional = false,
  disabled = false,
  className = '',
}) => {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && (
        <label className="text-sm font-medium text-gray-700">
          {label}
          {optional && (
            <span className="text-gray-400 font-normal ml-1">(Optional)</span>
          )}
        </label>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
        className="form-input disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
      />
    </div>
  )
}

export default FormInput
