import React from 'react'
import { ChevronDown } from 'lucide-react'

const FormSelect = ({
  label,
  options = [],
  value,
  onChange,
  placeholder = 'Select...',
  className = '',
}) => {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && (
        <label className="text-sm font-medium text-gray-700">{label}</label>
      )}
      <div className="relative">
        <select
          value={value}
          onChange={onChange}
          className="form-select pr-9 text-gray-500"
        >
          <option value="" disabled>
            {placeholder}
          </option>
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
          <ChevronDown size={15} />
        </span>
      </div>
    </div>
  )
}

export default FormSelect
