import React, { useState } from 'react'
import FormInput from '../common/FormInput'
import FormSelect from '../common/FormSelect'
import Button from '../common/Button'

const INDIAN_STATES = [
  { value: 'AP', label: 'Andhra Pradesh' },
  { value: 'TG', label: 'Telangana' },
  { value: 'MH', label: 'Maharashtra' },
  { value: 'KA', label: 'Karnataka' },
  { value: 'TN', label: 'Tamil Nadu' },
  { value: 'DL', label: 'Delhi' },
  { value: 'GJ', label: 'Gujarat' },
  { value: 'RJ', label: 'Rajasthan' },
  { value: 'UP', label: 'Uttar Pradesh' },
  { value: 'WB', label: 'West Bengal' },
]

const CITIES = {
  AP: [
    { value: 'vijayawada', label: 'Vijayawada' },
    { value: 'visakhapatnam', label: 'Visakhapatnam' },
  ],
  TG: [
    { value: 'hyderabad', label: 'Hyderabad' },
    { value: 'warangal', label: 'Warangal' },
  ],
  MH: [
    { value: 'mumbai', label: 'Mumbai' },
    { value: 'pune', label: 'Pune' },
  ],
  KA: [
    { value: 'bangalore', label: 'Bangalore' },
    { value: 'mysore', label: 'Mysore' },
  ],
}

const BillingForm = ({ onCancel, onSave }) => {
  const [form, setForm] = useState({
    companyName: '',
    email: '',
    gstNumber: '',
    panNumber: '',
    premiseHouseNo: '',
    street: '',
    state: '',
    city: '',
    country: 'India',
    pinCode: '',
  })

  const handleChange = (field) => (e) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }))
  }

  const availableCities = CITIES[form.state] || []

  const handleSave = () => {
    onSave?.(form)
  }

  return (
    <div className="card p-8">
      {/* Page Title */}
      <h1 className="text-2xl font-bold text-gray-900 mb-6">
        Review your details
      </h1>

      {/* Section Title */}
      <h2 className="text-base font-semibold text-gray-800 mb-5">
        Billing Information
      </h2>

      {/* Form Grid */}
      <div className="flex flex-col gap-5">
        {/* Row 1: Company Name + Email */}
        <div className="grid grid-cols-2 gap-5">
          <FormInput
            label="Company Name"
            placeholder="abhigyan"
            value={form.companyName}
            onChange={handleChange('companyName')}
          />
          <FormInput
            label="Email"
            placeholder="abhigyan.pandey@getreelax.com"
            value={form.email}
            onChange={handleChange('email')}
            type="email"
          />
        </div>

        {/* Row 2: GST + PAN */}
        <div className="grid grid-cols-2 gap-5">
          <FormInput
            label="GST Number"
            optional
            placeholder="GST Number"
            value={form.gstNumber}
            onChange={handleChange('gstNumber')}
          />
          <FormInput
            label="PAN Number"
            optional
            placeholder="PAN Number"
            value={form.panNumber}
            onChange={handleChange('panNumber')}
          />
        </div>

        {/* Row 3: Premise + Street */}
        <div className="grid grid-cols-2 gap-5">
          <FormInput
            label="Premise/House no."
            placeholder="Premise/House no."
            value={form.premiseHouseNo}
            onChange={handleChange('premiseHouseNo')}
          />
          <FormInput
            label="Street"
            placeholder="Street"
            value={form.street}
            onChange={handleChange('street')}
          />
        </div>

        {/* Row 4: State + City */}
        <div className="grid grid-cols-2 gap-5">
          <FormSelect
            label="State"
            placeholder="Select state"
            options={INDIAN_STATES}
            value={form.state}
            onChange={handleChange('state')}
          />
          <FormSelect
            label="City"
            placeholder="Select city"
            options={availableCities}
            value={form.city}
            onChange={handleChange('city')}
          />
        </div>

        {/* Row 5: Country + Pin Code */}
        <div className="grid grid-cols-2 gap-5">
          <FormInput
            label="Country"
            placeholder="India"
            value={form.country}
            onChange={handleChange('country')}
            disabled
          />
          <FormInput
            label="Pin Code"
            placeholder="Pincode"
            value={form.pinCode}
            onChange={handleChange('pinCode')}
            type="text"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-end gap-3 mt-8 pt-6 border-t border-gray-100">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" onClick={handleSave}>
          Save Details
        </Button>
      </div>
    </div>
  )
}

export default BillingForm
