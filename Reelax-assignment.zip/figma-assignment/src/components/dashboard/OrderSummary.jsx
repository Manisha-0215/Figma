import React, { useState } from 'react'
import { Tag, ChevronUp, ChevronDown, CreditCard, ArrowUpCircle } from 'lucide-react'
import Button from '../common/Button'
import CouponSelector from './CouponSelector'

const OrderSummary = ({ onProceed }) => {
  const [couponOpen, setCouponOpen] = useState(true)
  const [couponCode, setCouponCode] = useState('')
  const [selectedCoupon, setSelectedCoupon] = useState('WELCOME20')
  const [walletApplied, setWalletApplied] = useState(false)

  const subtotal = 14999.0
  const taxRate = 0.18
  const tax = subtotal * taxRate
  const walletBalance = 500.0
  const walletDiscount = walletApplied ? walletBalance : 0
  const total = subtotal + tax - walletDiscount

  return (
    <div className="flex flex-col gap-4">
      {/* Plan Card */}
      <div className="card p-6">
        <h2 className="text-lg font-bold text-gray-900 mb-5">Order Summary</h2>

        {/* Price + Plan */}
        <div className="flex items-start justify-between mb-2">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-bold text-gray-900">₹4,999</span>
              <span className="text-sm text-gray-500 font-normal">/month</span>
            </div>
            <p className="text-xs text-gray-400 mt-1">Includes 5,000 credits/mo.</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold uppercase tracking-widest text-primary mb-0.5">
              Selected Plan
            </p>
            <p className="text-base font-bold text-gray-900">Startup</p>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-100 my-4" />

        {/* Upgrade to Growth Plan */}
        <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors cursor-pointer">
          <ArrowUpCircle size={16} className="text-primary" />
          Upgrade to Growth Plan
        </button>
      </div>

      {/* Wallet + Coupon Card */}
      <div className="card p-5 flex flex-col gap-4">
        {/* Wallet Balance */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
              <CreditCard size={15} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-800">Wallet Balance</p>
              <p className="text-xs text-gray-400">₹{walletBalance.toFixed(2)} available</p>
            </div>
          </div>
          <button
            onClick={() => setWalletApplied((v) => !v)}
            className={`
              text-sm font-semibold px-3 py-1.5 rounded-md border transition-all cursor-pointer
              ${walletApplied
                ? 'bg-primary text-white border-primary'
                : 'bg-white text-primary border-gray-200 hover:border-primary/50'
              }
            `}
          >
            {walletApplied ? 'Remove' : 'Apply'}
          </button>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-100" />

        {/* Apply Coupon Section */}
        <div>
          <button
            onClick={() => setCouponOpen((v) => !v)}
            className="w-full flex items-center justify-between cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <Tag size={15} className="text-gray-500" />
              <span className="text-sm font-semibold text-gray-800">Apply Coupon</span>
            </div>
            {couponOpen ? (
              <ChevronUp size={16} className="text-gray-400" />
            ) : (
              <ChevronDown size={16} className="text-gray-400" />
            )}
          </button>

          {couponOpen && (
            <div className="mt-3 flex flex-col gap-3">
              {/* Coupon Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Enter coupon code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 px-3 py-2.5 text-sm text-gray-700 border border-gray-200 rounded-lg 
                             placeholder-gray-400 outline-none focus:border-primary focus:ring-2 
                             focus:ring-primary/10 transition-all"
                />
                <button className="text-sm font-semibold text-primary px-3 py-2.5 border border-gray-200 
                                   rounded-lg hover:bg-primary/5 hover:border-primary/50 transition-all cursor-pointer whitespace-nowrap">
                  Apply
                </button>
              </div>

              {/* Coupon Options */}
              <CouponSelector
                selectedCoupon={selectedCoupon}
                onSelect={setSelectedCoupon}
              />
            </div>
          )}
        </div>
      </div>

      {/* Totals Card */}
      <div className="card p-5">
        {/* Line items */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Subtotal</span>
            <span className="text-sm font-semibold text-gray-800">
              ₹{subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Tax (18% GST)</span>
            <span className="text-sm font-semibold text-gray-800">
              ₹{tax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
          {walletApplied && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-green-600">Wallet Discount</span>
              <span className="text-sm font-semibold text-green-600">
                -₹{walletDiscount.toFixed(2)}
              </span>
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="border-t border-gray-100 my-4" />

        {/* Total */}
        <div className="flex items-center justify-between mb-5">
          <span className="text-sm font-semibold text-gray-800">Total due today</span>
          <span className="text-2xl font-bold text-primary">
            {total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </span>
        </div>

        {/* Proceed to Payment */}
        <Button
          variant="primary"
          size="lg"
          fullWidth
          onClick={onProceed}
          className="rounded-lg font-semibold text-sm py-3"
        >
          Proceed to Payment
        </Button>
      </div>
    </div>
  )
}

export default OrderSummary
