import React from 'react'

const COUPONS = [
  {
    id: 'WELCOME20',
    code: 'WELCOME20',
    description: '20% off on your first month',
  },
  {
    id: 'ANNUAL50',
    code: 'ANNUAL50',
    description: '50% off on annual plans',
  },
]

const CouponSelector = ({ selectedCoupon, onSelect }) => {
  return (
    <div className="flex flex-col gap-2 mt-3">
      {COUPONS.map((coupon) => {
        const isSelected = selectedCoupon === coupon.id
        return (
          <button
            key={coupon.id}
            onClick={() => onSelect(coupon.id)}
            className={`
              flex items-center justify-between px-3.5 py-2.5 rounded-lg border text-left
              transition-all duration-150 cursor-pointer w-full
              ${
                isSelected
                  ? 'border-primary bg-white'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }
            `}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-semibold text-gray-800">
                {coupon.code}
              </span>
              <span className="text-xs text-gray-500">{coupon.description}</span>
            </div>
            {/* Radio indicator */}
            <div
              className={`
                w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0
                transition-all duration-150
                ${
                  isSelected
                    ? 'border-primary bg-primary'
                    : 'border-gray-300 bg-white'
                }
              `}
            >
              {isSelected && (
                <div className="w-1.5 h-1.5 rounded-full bg-white" />
              )}
            </div>
          </button>
        )
      })}
    </div>
  )
}

export default CouponSelector
