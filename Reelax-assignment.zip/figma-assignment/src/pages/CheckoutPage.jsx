import React from 'react'
import BillingForm from '../components/dashboard/BillingForm'
import OrderSummary from '../components/dashboard/OrderSummary'
import BackLink from '../components/common/BackLink'

const CheckoutPage = () => {
  const handleBack = () => {
    console.log('Navigate back to plans')
  }

  const handleCancel = () => {
    console.log('Cancel clicked')
  }

  const handleSave = (formData) => {
    console.log('Save details:', formData)
  }

  const handleProceed = () => {
    console.log('Proceed to payment')
  }

  return (
    <div className="flex flex-col">
      {/* Back Link */}
      <BackLink label="Back to plans" onClick={handleBack} />

      {/* Two-column layout */}
      <div className="grid grid-cols-[1fr_380px] gap-5 items-start">
        {/* Left: Billing Form */}
        <BillingForm onCancel={handleCancel} onSave={handleSave} />

        {/* Right: Order Summary */}
        <div className="sticky top-[72px]">
          <OrderSummary onProceed={handleProceed} />
        </div>
      </div>
    </div>
  )
}

export default CheckoutPage
